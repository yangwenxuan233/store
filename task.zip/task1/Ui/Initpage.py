class Initpage:

    # Moisturizers
    moisturizers_data = [
        {"xpath": "/html/body/div[1]/div[2]/div[1]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[2]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[3]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[4]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[5]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[6]/button", "expect": "success"}
    ]

    # Sunscreens
    sunscreens_data = [
        {"xpath": "/html/body/div[1]/div[2]/div[1]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[2]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[3]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[4]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[5]/button", "expect": "success"},
        {"xpath": "/html/body/div[1]/div[2]/div[6]/button", "expect": "success"}
    ]
